// @ts-check

//#region Notes:
//  - context is a bridged NSDictionary, not a raw JavaScript object
//  - nil values are bridged as null
//  - sketchtool will log anything from print() and any errors that reach the top
//  of the call stack, *but* it seems sketchtool does not receive that logging until
//  the script reaches its end or or throws an error.
//  Fiber delays that finish, so if you never cleanup a fiber, your script won't end...
//  and errors and printed messages won't get logged.
//#endregion

//#region Main

function main(ctx){
    let fiber;

    function logResult(result){
        function logFailure(errorJSON){
            print(JSON.stringify({ type: "failure", content: errorJSON }));
        }

        if(result instanceof PluginError){
            logFailure(result.asJSONObject());
        } else if(result instanceof Error){
            logFailure(new PluginError("generic", result).asJSONObject());
        } else {
            print(JSON.stringify(result));
        }
    }

    try {
        // @ts-ignore
        fiber = require('sketch/async').createFiber();

        asyncMain(ctx)
            .then(logResult)
            .catch(logResult)
            .finally(() => {
                fiber.cleanup();
            });
    } catch(error){
        if(fiber) fiber.cleanup();

        logResult(error);
    }
}

async function asyncMain(ctx){
    //  Instructions are sent as JSON, to avoid having to deal with Foundation objects
    //  and can instead deal with JS types

    const instructions = JSON.parse(ctx.instructionsFromStarkMacApp+"");

    if(!instructions){
        throw new PluginError('malformedInstructions');
    }

    //  Open document

    if(!instructions.documentPath){
        throw new PluginError('malformedInstructions');
    }

    let document;
    
    try {
        document = await openDocument(instructions.documentPath);
    } catch(error) {
        throw new PluginError('openDocumentFailed', error);
    }

    //  Center and fit layer in viewport

    if(instructions.layerIdToCenter){
        const layer = document.getLayerWithID(instructions.layerIdToCenter);

        if(layer){
            document.selectedPage = layer.getParentPage();
            document.sketchObject.contentDrawView().zoomToFitRect(layer.sketchObject.absoluteRect().rect());
        }
    }

    //  Find layers to modify

    // @ts-ignore
    const Style = require('sketch/dom').Style;

    let anyChangesFailed = false;

    for(const change of instructions.changes){
        const layer = document.getLayerWithID(change.layerId);

        if(!layer){
            anyChangesFailed = true;
            
            continue;
        }

        if(layer.style){
            layer.style.opacity = 1;
            layer.style.fills = [
                {
                    color: change.newFillColor,
                    fillType: Style.FillType.Color
                }
            ]
        } else {
            anyChangesFailed = true;
        }
    }

    if(anyChangesFailed){
        require('sketch/ui').message('❌ Error rectifying issues');

        throw new PluginError('someChangesFailed'); 
    } else {
        require('sketch/ui').message('✅ Issues successfully rectified');
    }

    return { type: "success" };
}

//#endregion


//#region Helpers

function openDocument(documentPath){
    return new Promise((resolve, reject) => {
        try {
            // @ts-ignore
            require('sketch/dom').Document.open(documentPath, (err, document) => {
                if(err){
                    reject(err);
                } else {
                    resolve(document);
                }
            });
        } catch(err) {
            reject(err);
        }
    });
}

class PluginError extends Error {

    constructor(pluginErrorType, additionalInfo) {
        super();

        this.pluginErrorType = pluginErrorType;
        this.additionalInfo = additionalInfo;
    }

    asJSONObject() {
        return {
            type: this.pluginErrorType,
            additionalInfo: this.additionalInfo+"",
            stack: this.stack
        }
    }

}

//#endregion